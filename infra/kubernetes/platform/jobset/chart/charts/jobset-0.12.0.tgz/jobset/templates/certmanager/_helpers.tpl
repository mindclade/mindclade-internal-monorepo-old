{{- /*
Copyright The Kubernetes Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/ -}}

{{/*
Create the name of the jobset webhook certificate issuer.
*/}}
{{- define "jobset.certManager.issuer.name" -}}
{{ include "jobset.name" . }}-self-signed-issuer
{{- end -}}


{{/*
Create the name of the jobset webhook certificate.
*/}}
{{- define "jobset.certManager.certificate.name" -}}
{{ include "jobset.name" . }}-cert
{{- end -}}


{{/*
Create the name of the jobset metrics certificate.
*/}}
{{- define "jobset.certManager.metricsCertificate.name" -}}
{{ include "jobset.name" . }}-metrics-cert
{{- end -}}
